package linkedlist_examples;


import java.util.*;
public class LinkedListMethods {
     public static void main(String args[]) {

       /* Linked List Declaration */
       LinkedList<String> linkedlist = new LinkedList<String>();

       /*add(String Element) is used for adding 
        * the elements to the linked list*/
       linkedlist.add("Item1");
       linkedlist.add("Item5");
       linkedlist.add("Item3");
       linkedlist.add("Item6");
       linkedlist.add("Item2");

       /*Display Linked List Content*/
       System.out.println("Linked List Content: " +linkedlist);

       /*Add First and Last Element*/
       linkedlist.addFirst("First Item");
       linkedlist.addLast("Last Item");
       System.out.println("LinkedList Content after addition: " +linkedlist);

       /*This is how to get and set Values*/
       Object firstvar = linkedlist.get(0);
       System.out.println("First element: " +firstvar);
       linkedlist.set(0, "Changed first item");
       Object firstvar2 = linkedlist.get(0);
       System.out.println("First element after update by set method: " +firstvar2);

       /*Remove first and last element*/
       linkedlist.removeFirst();
       linkedlist.removeLast();
       System.out.println("LinkedList after deletion of first and last element: " +linkedlist);

       /* Add to a Position and remove from a position*/
       linkedlist.add(0, "Newly added item");
       linkedlist.remove(2);
       System.out.println("Final Content: " +linkedlist); 
       
    // Adding element to front of LinkedList
       /* public boolean offerFirst(E e): Inserts the 
        * specified element at the front of this list.
        */
       linkedlist.offerFirst("NEW Element");
       System.out.println("NEW Element: " +linkedlist); 
       
       
       
       // Removing First element
       Object firstElement = linkedlist.removeFirst();
       System.out.println("\nElement removed: "+ firstElement);
    
       // Removing last Element
       Object lastElement = linkedlist.removeLast();
       System.out.println("Element removed: "+ lastElement);
    
       // LinkedList elements after remove
       System.out.println("\nList Elements after Remove:");
       for(String str2: linkedlist){
          System.out.println(str2);
       }
       
       
       // contains() method checks whether the element exists
       if (linkedlist.contains("CC")) {
          System.out.println("Element CC is present in List");
       } else {
          System.out.println("List doesn't have element CC");
        }
       
     }
}
