package linkedlist_examples;

import java.util.*;

public class LinkedListEx {
	public static void main(String args[]) {

		LinkedList<String> list = new LinkedList<String>();

		// Adding elements to the Linked list
		list.add("Steve");
		list.add("Carl");
		list.add("Raj");

		// Adding an element to the first position
		list.addFirst("Negan");

		// Adding an element to the last position
		list.addLast("Rick");

		// Adding an element to the 3rd position
		list.add(2, "Glenn");

		// Iterating LinkedList
		Iterator<String> iterator = list.iterator();
		while (iterator.hasNext()) {
			System.out.println(iterator.next());
		}

		list.removeFirst();

		// Removing Last element
		list.removeLast();

		// Iterating LinkedList
		Iterator<String> it = list.iterator();
		while (it.hasNext()) {
			System.out.print("--------------------------");
			System.out.print(it.next() + " ");
		}

		// removing 2nd element, index starts with 0
		//list.remove(1);
	}

}
