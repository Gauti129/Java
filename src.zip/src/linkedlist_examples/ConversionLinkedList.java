package linkedlist_examples;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class ConversionLinkedList {
 public static void main(String[] args) {
    LinkedList<String> linkedlist = new LinkedList<String>();
    linkedlist.add("Harry");
    linkedlist.add("Jack");
    linkedlist.add("Tim");
    linkedlist.add("Rick");
    linkedlist.add("Rock");
    
    
// LinkedList to ArrayList
    List<String> list = new ArrayList<String>(linkedlist);

    for (String str : list){
      System.out.println(str);
    }
    
    
  //Converting LinkedList to Array
    String[] array = linkedlist.toArray(new String[linkedlist.size()]);

    //Displaying Array content
    System.out.println("Array Elements:");
    for (int i = 0; i < array.length; i++)
    {
       System.out.println(array[i]);
    }
 }
}
