package linkedlist_examples;

import java.util.LinkedList;
class LinkedListClone {

  public static void main(String[] args) {

     // create a LinkedList
     LinkedList<String> list = new LinkedList<String>();

     // Adding elements to the LinkedList
     list.add("Element1");
     list.add("Element2");
     list.add("Element3");
     list.add("Element4");
     list.add("Element3");

     // Displaying LinkedList elements
     System.out.println("LinkedList elements: "+list);
 
     // Creating another list
     LinkedList<String> list2 = new LinkedList<String>();
 
     // Clone list to list2
     /* public Object clone(): Returns a shallow copy of this
      * LinkedList. (The elements themselves are not cloned.)
      */
     list2 = (LinkedList)list.clone();
 
     // Displaying elements of second LinkedList
     System.out.println("List 2 Elements: "+list2);
     
  // get the index of last occurrence of element "AA"
     /* public int lastIndexOf(Object o): Returns the index 
      * of the last occurrence of the specified element in 
      * this list, or -1 if this list does not contain the 
      * element. 
      */
     System.out.println("LastIndex of Element3:"+list.lastIndexOf("Element3"));
  }
}

