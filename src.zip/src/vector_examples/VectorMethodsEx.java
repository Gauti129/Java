package vector_examples;

import java.util.Vector;
public class VectorMethodsEx {
  public static void main(String[] args) {
     // Creating a Vector of String Elements
     Vector<String> vector = new Vector<String>();
 
     //Adding elements to the Vector
     vector.add("Harry");
     vector.add("Steve");
     vector.add("Vince");
     vector.add("David");
     vector.add("Matt");

     System.out.println("Vector elements before remove(): ");
     for(int i=0; i < vector.size(); i++)
     {
        System.out.println(vector.get(i));
     }
 
     // Removing Harry
     vector.remove("Harry");
     // Removing Matt
     vector.remove("Matt");
 
     System.out.println("\nVector elements after remove(): ");
     for(int i=0; i < vector.size(); i++)
     {
        System.out.println(vector.get(i));
     }
     
  // Calling clear() method of Vector API
   //  vector.clear();
  
   //  System.out.println("Size of Vector after clear(): "+vector.size());
     
     //Replacing index 1 element
     vector.set(1,"Mark");
     //Replacing index 2 element
     vector.set(2,"Jack");
 
     System.out.println("Vector elements after replacement: ");
     for(int i=0; i < vector.size(); i++)
     {
        System.out.println(vector.get(i));
     }
     
  }
}

