package vector_examples;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Vector;
public class ConvertVector {
 
  public static void main(String[] args) {
 
     // Step1: Creating a Vector of String elements
     Vector<String> vector = new Vector<String>();
 
     // Step2: Populating Vector
     vector.add("Tim");
     vector.add("Rock");
     vector.add("Hulk");
     vector.add("Rick");
     vector.add("James");
 
    // Step3: Displaying Vector elements
    System.out.println("Vector Elements :");
    for (String str : vector){
       System.out.println(str);
    }
 
    // Step4: Converting Vector to List
    List<String> list = Collections.list(vector.elements());
 
    // Step 5: Displaying List Elements
    System.out.println("\nList Elements :");
    for (String str2 : list){
       System.out.println(str2);
    }
    
    
  //Converting Vector to ArrayList
    ArrayList<String> arraylist = new ArrayList<String>(vector);

    //Displaying ArrayList Elements
    System.out.println("\nArrayList Elements :");
    for (String s : arraylist){
       System.out.println(s);
    }	
    
    
    
  //Converting Vector to String Array
    String[] array = vector.toArray(new String[vector.size()]);
 
    //Displaying Array Elements
    System.out.println("String Array Elements :");
    for(int i=0; i < array.length ; i++){
       System.out.println(array[i]);
    }
    
    ArrayList<String> arraylist1 = new ArrayList<String>(vector);
    
    //Displaying ArrayList Elements
    System.out.println("\nArrayList Elements present :");
    for (String s : arraylist){
       System.out.println(s);
    }	
    
 }
}
